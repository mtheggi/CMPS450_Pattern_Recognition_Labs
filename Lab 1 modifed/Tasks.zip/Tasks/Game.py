import numpy as np

# TODO [1]: implement the guessing_game function
def guessing_game(): # hint: return type is tuple[bool, list[int], int]:
    pass

# TODO [2]: implement the play_game function
def play_game()-> None:
    max_value:int = 20
    attempts:int = 5
    pass
            

